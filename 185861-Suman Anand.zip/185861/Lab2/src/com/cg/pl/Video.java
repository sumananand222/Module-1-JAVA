package com.cg.pl;

public class Video extends MediaItem{
	
	public Video(int bookId, String title, int noCopies, int runtime) {
		super(bookId, title, noCopies, runtime);
		// TODO Auto-generated constructor stub
	}
	private String director;
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public String getVideogenre() {
		return videogenre;
	}
	public void setVideogenre(String videogenre) {
		this.videogenre = videogenre;
	}
	public int getYor() {
		return yor;
	}
	public void setYor(int yor) {
		this.yor = yor;
	}
	private String videogenre;
	private int yor;//year of Release
	@Override
	public void checkIn(int bookId) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void checkOut(int bookId) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Item addItem(int id1, String title, String author, int noCopies) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void print() {
		// TODO Auto-generated method stub
		
		
	}


}
