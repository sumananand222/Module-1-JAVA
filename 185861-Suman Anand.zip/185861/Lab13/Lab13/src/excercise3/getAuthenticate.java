package excercise3;

public interface getAuthenticate {
void authenticate(String username,String password);
}
