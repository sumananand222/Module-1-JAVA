package excercise2;

public interface getSpace {
void insertSpace(String str);
}
